﻿namespace PAN_IDENTIFIER.Models
{
    internal class JournalInfoModel
    {
        public string? PAN { get; set; }
        public string? JOURNAL_TITLE {  get; set; }
        public string? ISSN { get; set; }
        public string? eISSN { get; set; }
    }
}
